package com.example.alejandro.app1.models;

/**
 * Created by Kartik on 3/17/2017.
 */

public class Game {
}
