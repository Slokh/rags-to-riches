unzip into home directory
./inttest.sh
for integration testing
./unit_test.sh
for unit testing
Unfortunately, due to the heavily coupled nature of the Activity classes, there is no way to unit test them. However, they do work together for the final result so they work integratedly. 