unzip into home directory
./inttest.sh
for integration testing
./unit_test.sh
for unit testing